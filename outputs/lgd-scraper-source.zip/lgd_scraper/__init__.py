"""WooCommerce catalog scraper."""

